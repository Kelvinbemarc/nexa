from flask import Flask, render_template, redirect, url_for, flash, request
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_bcrypt import Bcrypt  # Import Bcrypt
from werkzeug.security import generate_password_hash, check_password_hash
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import InputRequired, Length, ValidationError, Email
from flask_mail import Mail, Message
from werkzeug.utils import secure_filename
from flask import jsonify
from datetime import datetime


import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://username and password here@localhost/nexa'
app.config['UPLOAD_FOLDER'] = 'static/uploads'  # Ensure this folder exists
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif', 'mp3', 'wav', 'mp4'}
app.config['MAIL_SERVER'] = 'smtp.yourmailserver.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USERNAME'] = 'youremail@domain.com'
app.config['MAIL_PASSWORD'] = 'yourpassword'
app.config['MAIL_USE_TLS'] = True

db = SQLAlchemy(app)
bcrypt = Bcrypt(app)  # Initialize Bcrypt
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
mail = Mail(app)

# Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    profile_picture = db.Column(db.String(255), nullable=True)  # New field for profile picture
    profile_picture = db.Column(db.String(100), nullable=True)  # Assuming you have a profile picture field


# Content table with additional fields
class Content(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    file_path = db.Column(db.String(200), nullable=False)
    likes_count = db.Column(db.Integer, default=0)  # Update this to likes_count
    comments_count = db.Column(db.Integer, default=0)
    
    shares = db.Column(db.Integer, default=0)


# Comments table
class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content_id = db.Column(db.Integer, db.ForeignKey('content.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    text = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

@app.route('/like/<int:content_id>', methods=['POST'])
@login_required
def like_content(content_id):
    content = Content.query.get_or_404(content_id)
    content.likes_count += 1  # Update to the correct attribute name
    db.session.commit()
    return jsonify({'likes': content.likes_count})


@app.route('/comment/<int:content_id>', methods=['POST'])
@login_required
def comment_content(content_id):
    text = request.form.get('comment')
    comment = Comment(content_id=content_id, user_id=current_user.id, text=text)
    db.session.add(comment)
    db.session.commit()

    content = Content.query.get_or_404(content_id)
    content.comments_count += 1
    db.session.commit()

    return jsonify({'comments_count': content.comments_count})

@app.route('/share/<int:content_id>', methods=['POST'])
@login_required
def share_content(content_id):
    content = Content.query.get_or_404(content_id)
    content.shares += 1
    db.session.commit()
    return jsonify({'shares': content.shares})



# Forms
class RegisterForm(FlaskForm):
    username = StringField(validators=[InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "Username"})
    email = StringField(validators=[InputRequired(), Email(message='Invalid email'), Length(max=50)], render_kw={"placeholder": "Email"})
    password = PasswordField(validators=[InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "Password"})
    submit = SubmitField("Register")

    def validate_username(self, username):
        existing_user_username = User.query.filter_by(username=username.data).first()
        if existing_user_username:
            raise ValidationError("That username already exists. Please choose a different one.")

    def validate_email(self, email):
        existing_user_email = User.query.filter_by(email=email.data).first()
        if existing_user_email:
            raise ValidationError("That email is already in use. Please choose a different one.")

class LoginForm(FlaskForm):
    username = StringField(validators=[InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "Username"})
    password = PasswordField(validators=[InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "Password"})
    submit = SubmitField("Login")

class NetworkUser(db.Model):
    __tablename__ = 'network_user'  # Replace this with the correct table name
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    profession = db.Column(db.String(100), nullable=True)
    location = db.Column(db.String(100), nullable=True)
    bio = db.Column(db.Text, nullable=True)
    profile_picture = db.Column(db.String(100), default='default_profile.png')  # Set a default profile picture



# User loader
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))



@app.route('/signup', methods=['GET', 'POST'])
def signup():
    form = RegisterForm()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        new_user = User(username=form.username.data, email=form.email.data, password_hash=hashed_password)
        db.session.add(new_user)
        db.session.commit()
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))
    return render_template('signup_login.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and bcrypt.check_password_hash(user.password_hash, form.password.data):
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash('Login failed. Please check your username and password.', 'danger')
    return render_template('signup_login.html', form=form)

@app.route('/dashboard', methods=['GET', 'POST'])
@login_required
def dashboard():
    if request.method == 'POST':
        # Handle file uploads
        video_file = request.files.get('video-file')
        media_file = request.files.get('media-file')
        title = request.form.get('title')
        description = request.form.get('description')

        if video_file and allowed_file(video_file.filename):
            video_filename = secure_filename(video_file.filename)
            video_file.save(os.path.join(app.config['UPLOAD_FOLDER'], video_filename))
            new_content = Content(user_id=current_user.id, title=title, description=description, file_path=video_filename)
            db.session.add(new_content)
            db.session.commit()

        if media_file and allowed_file(media_file.filename):
            media_filename = secure_filename(media_file.filename)
            media_file.save(os.path.join(app.config['UPLOAD_FOLDER'], media_filename))
            new_content = Content(user_id=current_user.id, title=title, description=description, file_path=media_filename)
            db.session.add(new_content)
            db.session.commit()

        flash('Media uploaded successfully!', 'success')
        return redirect(url_for('dashboard'))

    # Fetch uploaded content from the database
    uploaded_content = Content.query.filter_by(user_id=current_user.id).all()

    return render_template('dashboard.html', name=current_user.username, uploaded_content=uploaded_content)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

@app.route('/')
@app.route('/Home.html')
def home():
    return render_template('Home.html')

@app.route('/Artisthub.html')
def artist_hub():
    return render_template('Artisthub.html')



@app.route('/events.html')
def events():
    return render_template('events.html')

@app.route('/shop.html')
def shop():
    return render_template('shop.html')

@app.route('/contact.html')
def contact():
    return render_template('contact.html')



@app.route('/Network.html', methods=['GET', 'POST'])
@login_required
def network_portal():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        profession = request.form.get('profession')
        location = request.form.get('location')
        bio = request.form.get('bio')

        # Check if the user already exists in NetworkUser table
        existing_user = NetworkUser.query.filter_by(email=email).first()

        if existing_user:
            # Update existing user's information
            existing_user.name = name
            existing_user.profession = profession
            existing_user.location = location
            existing_user.bio = bio
            db.session.commit()
            flash('Your profile has been updated.', 'success')
        else:
            # Create a new NetworkUser entry
            new_user = NetworkUser(
                name=name,
                email=email,
                profession=profession,
                location=location,
                bio=bio
            )
            db.session.add(new_user)
            db.session.commit()
            flash('Welcome to the network!', 'success')

        return redirect(url_for('network_portal'))

    # Fetch current user's data from NetworkUser table
    network_user = NetworkUser.query.filter_by(email=current_user.email).first()

    if not network_user:
        flash('Please complete your network profile.', 'warning')
        return redirect(url_for('dashboard'))

    # Fetch profile picture from User table
    profile_picture = current_user.profile_picture

    # Fetch similar users from NetworkUser table based on profession
    similar_users = NetworkUser.query.filter(
        NetworkUser.profession == network_user.profession,
        NetworkUser.email != current_user.email
    ).all()

    # For each similar user, fetch their profile picture from User table
    users_with_pictures = []
    for user in similar_users:
        user_profile = User.query.filter_by(email=user.email).first()
        users_with_pictures.append({
            'name': user.name,
            'profession': user.profession,
            'location': user.location,
            'bio': user.bio,
            'profile_picture': user_profile.profile_picture if user_profile and user_profile.profile_picture else 'default_profile.png'
        })

    return render_template(
        'Network.html',
        network_user=network_user,  # Your profile data
        profile_picture=profile_picture,      # Your profile picture
        similar_users=users_with_pictures     # Similar users' profiles
    )




@app.route('/profile/<user_id>', methods=['GET'])
@login_required
def view_profile(user_id):
    # Fetch the user's profile using the email (user_id)
    network_user = NetworkUser.query.filter_by(email=user_id).first()

    if not network_user:
        flash('User not found.', 'danger')
        return redirect(url_for('network_portal'))

    # Fetch the corresponding User record
    user_record = User.query.filter_by(email=user_id).first()

    if not user_record:
        flash('User record not found.', 'danger')
        return redirect(url_for('network_portal'))

    # Fetch the user's media using the User.id
    media = Content.query.filter_by(user_id=user_record.id).all()

    return render_template('profile.html', network_user=network_user, media=media)






@app.route('/upload_profile_picture', methods=['POST'])
@login_required
def upload_profile_picture():
    if 'profile-picture' not in request.files:
        flash('No file part', 'danger')
        return redirect(url_for('dashboard'))

    file = request.files['profile-picture']

    if file.filename == '':
        flash('No selected file', 'danger')
        return redirect(url_for('dashboard'))

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)

        # Ensure the 'profile_pics' directory exists
        profile_pics_path = os.path.join(app.config['UPLOAD_FOLDER'], 'profile_pics')
        if not os.path.exists(profile_pics_path):
            os.makedirs(profile_pics_path)

        # Save the file in the 'profile_pics' directory
        file_path = os.path.join(profile_pics_path, filename)
        file.save(file_path)

        # Update the user's profile picture in the database
        current_user.profile_picture = filename
        db.session.commit()

        flash('Profile picture updated!', 'success')
        return redirect(url_for('dashboard'))

    flash('Invalid file type', 'danger')
    return redirect(url_for('dashboard'))

def allowed_file(filename):
    allowed_extensions = {'png', 'jpg', 'jpeg', 'gif'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions



if __name__ == "__main__":
    app.run(debug=True)
